<?php
    include("Include/db_pdo.php");
    include('Header/header.php');
    include("Include/tilbake.php");
?>
<?php
    include('Include/sjekkLov1.php');
?> 