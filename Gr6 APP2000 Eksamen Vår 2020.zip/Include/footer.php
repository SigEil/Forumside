<script src="JavaScript filer/slettInt.js"></script>
<script src="JavaScript filer/scroll.js"></script>