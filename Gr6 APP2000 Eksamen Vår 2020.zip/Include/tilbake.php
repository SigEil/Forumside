<?php 
      if(!isset($_SESSION['brukertype'])) {
        header("Location: logginn.php"); 
      } 
?>