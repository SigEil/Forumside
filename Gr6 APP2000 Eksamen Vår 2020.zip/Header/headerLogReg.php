<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Logg inn</title>

  <!-- CSS for Login/registrer -->
  <link rel="stylesheet" href="CSS filer/login-reg.css">
</head>
<body>
  <header>
  <nav>
    <!-- navbar oppdatert av Sanan den 22.01.2020 -->
        <section class="topnav" id="myTopnav">
            <a href="default.php" id="logo"  tabindex="1" id="først">Greentalk</a>
            <a href="default.php#omoss" id="høyre" tabindex="2">Om oss</a>
            <a href="default.php#aktuelt" id="høyre" tabindex="3">Aktuelt</a>
            <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <img src="Bilder/ikoner/b.svg" >
            </a>
        </section>
    </nav>
  </header>
</html>
<!-- Skrevet og kontrollert i fellesskap av Gruppe 6 -->
